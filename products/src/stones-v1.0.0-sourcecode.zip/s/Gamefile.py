import pickle


def BeginGame():
    want = input('Sure to begin the game? ([y]/n)')
    if want == 'n':
        print('Back to the Starting Interface.')
        return
    f = open('name.data', 'rb')
    names = pickle.load(f)
    f.close()
    numbers = int(input('Press down the numbers of the stones:(The number must ba odd!!!)\n'))
    if numbers % 2 == 0:
        print('The number must ba odd!!!')
        return
    print('''=====================================================================================================
The game begin!
=====================================================================================================
Be ready to start the game...
=====================================================================================================
The two players are 1 - ''' + names[0] + ' 2 - ' + names[1] + '''
=====================================================================================================
Welcome the players!
=====================================================================================================
''' + names[0] + ',you are the first!\n' +
          '=====================================================================================================')
    stone = '●'
    have = [0, 0]
    while 1:
        try:
            get_1 = int(input(names[0] + ',how many stones would you want?\n'))
        except ValueError:
            print('The number of the stones you get must be 1 or 2.')
            print('Return this inning.')
            continue

        if get_1 == 1 or get_1 == 2:
            if numbers - get_1 >= 0:
                have[0] += get_1
                show = ['', '', '']
                for i in range(have[0]):
                    show[0] += stone
                for i in range(have[1]):
                    show[1] += stone
                numbers -= get_1
                for i in range(numbers):
                    show[2] += stone
                print(names[0] + '\'s stones:' + show[0] + str(have[0]) + '\n' + names[1] + '\'s stones:' + show[1]
                      + str(have[1]) + '\nOthers:' + show[2] + str(numbers))

                if not numbers > 0:
                    print('The game finished.')
                    print('''Harry to find the winner...
=====================================================================================================''')
                    break

            else:
                print('The number of the stones you get must be larger than others.')
                print('Return this inning.')
                continue

        else:
            print('The number of the stones you get must be 1 or 2.')
            print('Return this inning.')
            continue

        # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
        try:
            get_2 = int(input(names[1] + ',how many stones would you want?\n'))
        except ValueError:
            print('The number of the stones you get must be 1 or 2.')
            print('Return this inning.')
            have[0] -= get_1
            continue

        if get_2 == 1 or get_2 == 2:
            if numbers - get_2 >= 0:
                have[1] += get_2
                show = ['', '', '']
                for i in range(have[0]):
                    show[0] += stone
                for i in range(have[1]):
                    show[1] += stone
                numbers -= get_2
                for i in range(numbers):
                    show[2] += stone
                print(names[0] + '\'s stones:' + show[0] + str(have[0]) + '\n' + names[1] + '\'s stones:' + show[1] +
                      str(have[1]) + '\nOthers:' + show[2] + str(numbers))

                if not numbers > 0:
                    print('The game finished.')
                    print('''Harry to find the winner...
=====================================================================================================''')
                    break

            else:
                print('The number of the stones you get must be larger than others.')
                print('Return this inning.')
                numbers += get_1
                have[0] -= get_1
                continue

        else:
            print('The number of the stones you get must be 1 or 2.')
            print('Return this inning.')
            numbers += get_1
            have[0] -= get_1
            continue

    if have[0] % 2 != 0:
        print('The final winner is ' + names[0] + '!')
    else:
        print('The final winner is ' + names[1] + '!')

    print('''Celebrate!!!!!!!!!!
=====================================================================================================''')
    return
