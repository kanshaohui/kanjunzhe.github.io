from tqdm import tqdm
from Gamefile import *
import time
import pickle


def NameChanging():
    f = open('name.data', 'rb')
    names = pickle.load(f)
    f.close()
    print('The original name is ' + names[0] + ' and ' + names[1] + '.')
    want = input('Would you want to change it? ([y]/n)')
    if want.lower() == 'n':
        return
    elif want.lower() == 'y' or not want:
        new_1 = input('Please down the first person\'s name:\n')
        new_2 = input('Please down the last person\'s name:\n')
        if new_1 != new_2:
            f = open('name.data', 'wb')
            pickle.dump([new_1, new_2], f)
            f.close()
            print('Success.')
        else:
            print('Filled.\nThe two names must be different.')
    else:
        print('Please press down it in order.')


def Help():
    print('''=====================================================================================================
This is a small game.It imitates a simple stone picking game.
The rules of the game:
    (1).The game is between two persons.The default name is A and B.you can change it with service 2.
    (2).The number of the stones must be odd.
    (3).You can only take 1 or 2 stones in one go.
    (4).After the game finish,the person with the odd number of stones is the winner.
    (5).Follow the tips.
The service of the game:
    Help ---------------------------------------------------------------------------------------- 0
    Begin the Game ------------------------------------------------------------------------------ 1
    Change the Names ---------------------------------------------------------------------------- 2
    Quit the Game ------------------------------------------------------------------------------- 3
=====================================================================================================''')


def start():
    BeginGame()


def wait(level=100, num=1, NCOLS=100, unit='it', name='Example', times=0.5, leave=True, scale=True):
    for i in range(num):
        for _ in tqdm(range(level), desc=name, leave=leave, ncols=NCOLS, unit_scale=scale, unit=unit):
            time.sleep(times)


def Quit():
    wait(level=20, name='Closing', times=0.1, unit='k·it')
    input('Press down enter to quit...')
    raise SystemExit


wait(level=2, unit='B·.py', name='Opening', times=0.2)
wait(level=10, unit='KB·.txt|.log', name='Opening', times=0.1)
wait(level=15, unit='KB·.o|.json|.sln|.h|.*', name='Opening', times=0.09)
wait(level=30, unit='KB·.dll|.db|.hml|.pyc', name='Opening', times=0.2)
wait(level=30, unit='MB·.exe', name='Opening', times=0.2)
Help()
while 1:
    service = input('Press down the service.\n')
    if service == '0':
        Help()
    elif service == '1':
        start()
    elif service == '2':
        NameChanging()
    elif service == '3':
        Quit()
    else:
        print('Please press down the service in order.')
