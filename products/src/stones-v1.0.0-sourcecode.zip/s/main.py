import os


if __name__ == "__main__":
    os.system("start cmd.exe cmd /k python core.py")
