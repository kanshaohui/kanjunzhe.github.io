from getData import loadPassword, init, savePassword


init()
savePassword()
form = loadPassword()


def EncryCode(password):
    password = password.lower()
    secret = 'X'

    for i in password:
        secret += form[i]

    while len(secret) % 4 != 0:
        secret += '0'

    num = 0
    num_list = [0]

    while num <= len(secret):
        num += 4
        num_list.append(num)

    del num
    data = []

    for i in range(len(secret) // 4):
        data.append(secret[num_list[i]:num_list[i + 1]])

    del num_list
    del secret
    answer = ' '.join(data)
    return answer


def DecryCode(password):
    password = ''.join(password.split())[1:-1]
    if password[-2:] == '00':
        password = password[:-2]

    num = 0
    num_list = [0]

    while num <= len(password):
        num += 2
        num_list.append(num)

    del num
    data = []

    for i in range(len(password) // 2):
        data.append(password[num_list[i]:num_list[i + 1]])

    del num_list
    del password
    answer = ''
    for i in data:
        answer += list(form.keys())[list(form.values()).index(i)]

    del data
    return answer


def SecondEncry(password):
    password = 'XX' + ''.join(EncryCode(password).split()) + 'XX'
    num = 0
    num_list = [0]

    while num <= len(password):
        num += 2
        num_list.append(num)

    del num
    data = []

    for i in range(len(password) // 2):
        data.append(password[num_list[i]:num_list[i + 1]])

    del num_list
    del password
    answer = ''
    for i in data:
        answer += list(form.keys())[list(form.values()).index(i[::-1])]

    del data
    return answer


def SecondDecry(password):
    password = ''.join(EncryCode(password)[1:-1].split())

    data = []
    for i in range(2, len(password), 2):
        data.append(password[i: i + 2])

    if data[-2:] == '00':
        data = data[:-2]
    if data[-2:] == 'XX':
        data = data[:-2]

    del password

    answer_first = ''
    for i in range(len(data)):
        answer_first += data[i]
        if i % 2 == 0:
            answer_first += ' '
    print(answer_first)
    # answer = 0  # DecryCode(data)
    # return answer_first
