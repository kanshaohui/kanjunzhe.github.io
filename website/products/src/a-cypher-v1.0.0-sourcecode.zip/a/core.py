from SecretCode import *
import time
import pickle
from tqdm import tqdm


def wait(level=100, num=1, NCOLS=100, unit='it', name='Example', times=0.5, leave=True, scale=True):
    for i in range(num):
        for _ in tqdm(range(level), desc=name, leave=leave, ncols=NCOLS, unit_scale=scale, unit=unit):
            time.sleep(times)


def JoinIn():
    password_file = open('A_Cypher Important/A_Cypher Passwords/password.data', 'rb')
    password = pickle.load(password_file)
    password_file.close()
    del password_file
    password_input = input('Press down the password(The default one:the maker\'s QQ number)\n')
    if password_input != password:
        print('Filled.\nYou must press down the right password.')
        # warn = logging("User warning:The user didn't press down the right password.", 'WARNING')
        # saveLog(warn, level='WARNING')
        Quit()
    else:
        print('Success.\nContinue the program.')
        # info = logging("LogIn Info:The user load into the cypher program.")
        # saveLog(info, level='INFO')


def Changing():
    original_file = open('A_Cypher Important\\A_Cypher Passwords\\password.data', 'rb')
    original = pickle.load(original_file)
    original_file.close()
    original_input = input('Press down the old password:\n')
    if original == original_input:
        new = input('Success.\nPlease press down the new password.\n')
        new_2 = input('Press down the new password again.\n')
        if new == new_2:
            wait(level=10, name='Changing')
            original_file = open('A_Cypher Important\\A_Cypher Passwords\\password.data', 'wb')
            pickle.dump(new_2, original_file)
            original_file.close()
            # info = logging("The user changes the password as " + new)
            # saveLog(info, level='INFO')
            print('Success.\nYou can use the new password now.')
        else:
            print('Filled.\nYou must check the two new password if they are the same.')
            # info = logging("Changing info:The two new password the user pressed down isn't the same.")
            # saveLog(info, level='INFO')
    else:
        print('Filled.\nYou must press down the right password.')
        # warn = logging("User warning:The user didn't press down the right password.", level='WARNING')
        # saveLog(warn, level='WARNING')
        return


def HelpFile():
    print("""                  Welcome to use A Encryption system.
===========================================================
You can press down these keys and they have these functions:
                0 ------------------- Help
                1 ------------- Encryption
                2 ------------- Decryption
                3 ------- DoubleEncryption
                4 ------- DoubleDecryption(Researching)
                5 -------------- Searching
                6 ------------------- Quit
    """)


def Quit():
    wait(level=20, name='Closing', times=0.1, unit='k·it')
    # info = logging("Quit info:The user quit the program.")
    # saveLog(info, level='INFO')
    input('Press down enter to quit...')
    raise SystemExit


def Encry():
    JoinIn()
    password = input('Press down the original text.\n')
    try:
        wait(name='Encryption', times=0.1, level=10)
        # info = logging("The user encry the text like " + password)
        # saveLog(info, level='INFO')
        print(EncryCode(password))
    except KeyError:
        # error = logging('The user press down the wrong text like ' + password, level='ERROR')
        # saveLog(error, level='ERROR')
        print('Please write it in order.')


def Decry():
    JoinIn()
    password = input('Press down the cipher text.\n')
    try:
        wait(name='Decryption', times=0.1, level=10)
        # info = logging("The user decry the text like " + password)
        # saveLog(info, level='INFO')
        print(DecryCode(password))
    except ValueError:
        # error = logging('The user press down the wrong text like ' + password, level='ERROR')
        # saveLog(error, level='ERROR')
        print('Please write it in order.')


def DoubleEncry():
    JoinIn()
    password = input('Press down the original text.\n')
    try:
        wait(name='Double Encryption', times=0.1, level=10)
        # info = logging("The user encry the text twice like " + password)
        # saveLog(info, level='INFO')
        print(SecondEncry(password))
    except KeyError:
        # error = logging('The user press down the wrong text like ' + password, level='ERROR')
        # saveLog(error, level='ERROR')
        print('Please write it in order.')
    except ValueError:
        # error = logging('The user press down the wrong text like ' + password, level='ERROR')
        # saveLog(error, level='ERROR')
        print('Please write it in order.')


def Search():
    JoinIn()
    while True:
        password = input('Press down the letter you want to search:\n')
        try:
            if len(password) == 1:
                wait(name='Searching', times=0.1, level=20)
                # info = logging("The user search the letter as " + password)
                # saveLog(info, level='INFO')
                print('The answer to \'' + password + '\' is \'' + form[password] + '\'')
                break
            else:
                print('Please write it in order.')
                # warn = logging('The user press down the wrong letter like ' + password, level='WARNING')
                # saveLog(warn, level='WARNING')
        except KeyError:
            print('Please write it in order.Or we don\'t have this word in the form.')
            # error = logging('The user press down the not-exist letter like ' + password, level='ERROR')
            # saveLog(error, level='ERROR')


wait(level=2, unit='B·.py', name='Opening', times=0.2)
wait(level=10, unit='KB·.txt|.log', name='Opening', times=0.1)
wait(level=15, unit='KB·.o|.json|.sln|.h|.user', name='Opening', times=0.09)
wait(level=30, unit='KB·.dll|.db|.hml', name='Opening', times=0.2)
wait(level=30, unit='MB·.exe', name='Opening', times=0.2)

f = open('./A_Cypher Important/A_Cypher Passwords/password.data', 'wb')
pickle.dump('3359688605', f)
f.close()

JoinIn()
HelpFile()

while True:
    service = input('Press down the service.\n')
    if service == '0':
        HelpFile()
    elif service == '1':
        Encry()
    elif service == '2':
        Decry()
    elif service == '3':
        DoubleEncry()
    elif service == '5':
        Search()
    elif service == '6':
        Quit()
    else:
        print('Please press down the service in order.')
