import os
import shutil
import time
import pickle

__form = {'a': '61', 'b': '62', 'c': '63', 'd': '64', 'e': '65', 'f': '71', 'g': '72', 'h': '73', 'i': '74',
          'j': '74', 'k': '75', 'l': '81', 'm': '82', 'n': '83', 'o': '84', 'p': '85', 'q': '91', 'r': '92',
          's': '93', 't': '94', 'u': '95', 'v': '01', 'w': '02', 'x': '03', 'y': '04', 'z': '05', ' ': '6X',
          ',': '7X', '.': '8X', '_': '5X', '?': '9X', '!': '0X', '(': 'X1', ')': '20', ':': 'X2', '"': 'X3',
          "'": '4X', '#': 'XX', '-': '5X', '|': '00', '@': '10', '=': '30', '+': '40', '%': '50', '\n': '60',
          '\t': '70', ';': '80', '&': '90'}


def init():
    try:
        os.makedirs('A_Cypher Important\\A_Cypher Passwords')
    except FileExistsError:
        pass

    try:
        os.makedirs('A_Cypher Important\\A_Cypher Logs')
    except FileExistsError:
        pass


def savePassword():
    shutil.rmtree('A_Cypher Important\\A_Cypher Passwords')
    os.makedirs('A_Cypher Important\\A_Cypher Passwords')
    __f = open('A_Cypher Important\\A_Cypher Passwords\\Passwords.data', 'wb')
    pickle.dump(__form, __f)
    __f.close()


def loadPassword():
    __f = open('A_Cypher Important\\A_Cypher Passwords\\Passwords.data', 'rb')
    __Password = pickle.load(__f)
    __f.close()
    return __Password


def saveLog(log, level='DEBUG'):
    _time = time.gmtime()
    name = str(_time.tm_year) + '_' + str(_time.tm_mon) + '_' + str(_time.tm_mday) + '.' +\
        str(_time.tm_hour) + ':' + str(_time.tm_min) + ':' + str(_time.tm_sec)
    name_short = str(_time.tm_year) + '_' + str(_time.tm_mon) + '_' + str(_time.tm_mday)
    os.makedirs('.\\A_Cypher Important\\A_Cypher Logs\\' + name_short + '\\Log - ' + level + ' - ' + name + '\\')
    __t = open('.\\A_Cypher Important\\A_Cypher Logs\\' + name_short + '\\Log - ' + level + ' - ' + name + '\\log - '
               + level + ' - ' + name + '.txt', 'w')
    __l = open('.\\A_Cypher Important\\A_Cypher Logs\\' + name_short + '\\Log - ' + level + ' - ' + name + '\\log - '
               + level + ' - ' + name + '.log', 'w')
    __t.write(log)
    __l.write(log)
    __t.close()
    __l.close()
