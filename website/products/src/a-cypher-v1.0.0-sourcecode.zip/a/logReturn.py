from time import gmtime as _time


def log_getting(text, level='INFO', logName='QRA-LOG'):
    time_now = str(_time().tm_year) + '_' + str(_time().tm_mon) + '_' + str(_time().tm_mday) + ' ' +\
        str(_time().tm_hour) + ':' + str(_time().tm_min) + ':' + str(_time().tm_sec)
    return time_now + ',' + logName + ' - ' + level + ' - ' + text
