import os


def main():
    os.system("cls")

    while 1:
        menu()
        service = input()

        if service == "1":
            putin()

        elif service == "2":
            search_name()

        elif service == "3":
            search_level()

        elif service == "4":
            search_date()

        elif service == "5":
            search()

        elif service == "6":
            putout()

        elif service == "0":
            break

        os.system("pause")
        os.system("cls")

    os.system("pause")
    os.system("exit")


def menu():
    print("====================================================")
    print("============== 事件记录工具 Recorder ===============")
    print("====================================================")
    print("|Computer and Data Safety Office all right reserved|")
    print("====================================================")
    print("|保障数据安全与隐私安全，就是保障人们的切身利益;   |")
    print("|合理使用电子产品，保护电教设备，就是保障课堂。    |")
    print("====================================================")
    print("\t\t1. 录入事件数据")
    print("\t\t2. 按姓名查数据")
    print("\t\t3. 按等级查数据")
    print("\t\t4. 按日期查数据")
    print("\t\t5. 级别代号查询")
    print("\t\t6. 浏览事件数据\n")
    print("\t\t0. 退出工具程序")
    print("====================================================")
    print("请输入您需要使用的服务：")


def putin():
    print("请按照以下格式录入数据：")
    print("年份-月份-日期 小时:分钟 学生姓名 事件等级 事件内容(-) 处理方式(-)")

    f = open(".\\info.txt", "a", encoding="utf-8")
    f.write(input() + "\n")
    f.close()


def putout():
    print("日期 时间 学生姓名 事件等级 事件内容(-) 处理方式(-)")
    f = open(".\\info.txt", "r", encoding="utf-8")

    for c in f.readlines():
        print(c[:-1])

    f.close()


def search():
    print("0级 - 测试级别，无实意             (Debug)")
    print("1级 - 小规模影响级别，即造成影响极小")
    print("2级 - 单一性级别，即对单独个体或部分整体造成影响")
    print("3级 - 大规模影响级别，即对班集体大部分成员造成影响")
    print("4级 - 大型影响级别，即造成小规模或小团体骚乱")
    print("5级 - 超大型影响级别，即造成难以终止的骚乱")
    print("6级 - 强针对性级别，即针对个体的叠加性影响")


def search_name():
    print("请输入需要查询的人员名称：")
    name = input()

    f = open(".\\info.txt", "r", encoding="utf-8")
    content = f.readlines()
    f.close()

    print("日期 时间 学生姓名 事件等级 事件内容(-) 处理方式(-)")
    flag = 0

    for c in content:
        if name in c:
            print(c[:-1])
            flag = 1

    if flag == 0:
        print("没有查询到结果！")


def search_level():
    print("请输入需要查询的等级代号：")
    level = input()

    f = open(".\\info.txt", "r", encoding="utf-8")
    content = f.readlines()
    f.close()

    print("日期 时间 学生姓名 事件等级 事件内容(-) 处理方式(-)")
    flag = 0

    for c in content:
        if c.split()[3] == level:
            print(c[:-1])
            flag = 1

    if flag == 0:
        print("没有查询到结果！")


def search_date():
    print("请输入需要查询的日期：")
    date = input()

    f = open(".\\info.txt", "r", encoding="utf-8")
    content = f.readlines()
    f.close()

    print("日期 时间 学生姓名 事件等级 事件内容(-) 处理方式(-)")
    flag = 0

    for c in content:
        if c.split()[0] == date:
            print(c[:-1])
            flag = 1

    if flag == 0:
        print("没有查询到结果！")


if __name__ == "__main__":
    main()
