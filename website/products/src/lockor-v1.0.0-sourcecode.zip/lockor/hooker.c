#include "hooker.h"

int InstallHook()
{
	g_hMouseHook = SetWindowsHookEx(WH_MOUSE, MouseProc, GetModuleHandle(L"hooker"), 0);
	if (g_hMouseHook == NULL)
		return 0;

	g_hKeyboardHook = SetWindowsHookEx(WH_KEYBOARD, KeyboardProc, GetModuleHandle(L"hooker"), 0);
	if (g_hKeyboardHook == NULL)
		return 0;

	return 1;
}

int UninstallHook()
{
	return UnhookWindowsHookEx(g_hMouseHook);
	return UnhookWindowsHookEx(g_hKeyboardHook);
}

LRESULT CALLBACK MouseProc(int code, WPARAM wParam, LPARAM lParam)
{
	return 1;
}

LRESULT CALLBACK KeyboardProc(int code, WPARAM wParam, LPARAM lParam)
{
	return 1;
}
