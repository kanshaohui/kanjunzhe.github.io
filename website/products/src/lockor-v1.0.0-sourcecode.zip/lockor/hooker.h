#include <Windows.h>

HHOOK g_hMouseHook;
HHOOK g_hKeyboardHook;

__declspec(dllexport) int InstallHook();
__declspec(dllexport) int UninstallHook();

LRESULT CALLBACK MouseProc(int code, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK KeyboardProc(int code, WPARAM wParam, LPARAM lParam);
